# Saint Alpha Roadmap

## v0.1 — current
- Mobile-friendly UI
- Field Library
- Alpha Vault
- Research Lab
- Prototype simulator
- Correlation guard
- Reduce-correlation workflow
- Multi-region settings
- Local persistence for core field/region data

## v0.2
- CSV field import
- Edit field metadata
- Full research history
- Export alpha formula/settings
- Better local simulator

## v0.3
- Secure backend
- AI research engine
- Structured candidate generation
- Research memory

## v0.4
- Historical market-data engine
- More rigorous simulation
- Portfolio construction
- Robustness tests

## v1.0
- Cloud sync
- Authentication
- AI-assisted research
- Production Android/web releases
