# Saint Alpha MVP
Research. Simulate. Evolve.

A free-first quantitative alpha research laboratory prototype.

## Included
- Dashboard
- Research Lab
- Field Library with add/update/delete/import-ready UI
- Alpha Vault
- Correlation Guard
- Reduce Correlation workflow
- Simulator with transparent demo metrics
- Research history
- Multi-region settings
- WorldQuant formula export/copy-ready workflow

## Run
Requires Flutter 3.x.

```bash
flutter pub get
flutter run
```

For web:
```bash
flutter run -d chrome
```

## Important
The built-in simulator is a prototype research simulator, not an official WorldQuant Brain simulator. Official Brain results remain the final validation.
