CREATE TABLE regions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE fields (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  dataset TEXT,
  category TEXT,
  description TEXT,
  coverage REAL,
  status TEXT DEFAULT 'available'
);

CREATE TABLE alphas (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  formula TEXT NOT NULL,
  region TEXT,
  status TEXT NOT NULL,
  sharpe REAL,
  fitness REAL,
  correlation REAL
);

CREATE TABLE simulations (
  id TEXT PRIMARY KEY,
  alpha_id TEXT,
  sharpe REAL,
  fitness REAL,
  turnover REAL,
  drawdown REAL,
  created_at TEXT
);

CREATE TABLE correlation_checks (
  id TEXT PRIMARY KEY,
  candidate_alpha_id TEXT,
  reference_alpha_id TEXT,
  correlation REAL,
  decision TEXT,
  created_at TEXT
);
