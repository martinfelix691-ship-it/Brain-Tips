import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await SaintStore.load();
  runApp(SaintAlphaApp(store: store));
}

class SaintStore extends ChangeNotifier {
  List<String> fields = [
    'equity_sentiment_score',
    'news_impact_projection_score',
    'fscore_momentum',
    'fscore_total',
    'fnd6_newa1v1300_eps',
    'fnd6_newa1v1300_capx',
    'anl4_cfo_value',
    'anl4_bvps_value',
    'anl4_capex_low',
    'anl4_afv4_median_eps',
    'returns',
    'adv20',
    'low',
    'market',
    'opencap',
  ];

  List<Alpha> vault = [
    Alpha(
      id: 'SA-001',
      name: 'Fundamental Acceleration',
      formula: 'rank(ts_delta(fnd6_newa1v1300_eps,60))',
      sharpe: 2.79,
      fitness: 2.63,
      correlation: 0.00,
      region: 'USA',
    ),
  ];

  List<SimulationResult> history = [];
  String region = 'USA';
  String universe = 'TOP3000';
  int delay = 1;
  int decay = 6;
  String neutralization = 'Industry';
  double truncation = 0.08;
  double maxCorrelation = 0.70;

  static Future<SaintStore> load() async {
    final s = SaintStore();
    final prefs = await SharedPreferences.getInstance();
    final savedFields = prefs.getStringList('fields');
    if (savedFields != null && savedFields.isNotEmpty) s.fields = savedFields;
    final savedRegion = prefs.getString('region');
    if (savedRegion != null) s.region = savedRegion;
    return s;
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('fields', fields);
    await prefs.setString('region', region);
    notifyListeners();
  }

  void addField(String field) {
    if (field.trim().isEmpty || fields.contains(field.trim())) return;
    fields.add(field.trim());
    save();
  }

  void removeField(String field) {
    fields.remove(field);
    save();
  }

  SimulationResult simulate(String formula) {
    final seed = formula.codeUnits.fold<int>(0, (a, b) => a + b);
    final r = Random(seed);
    final sharpe = 0.85 + r.nextDouble() * 1.95;
    final fitness = 0.65 + sharpe * 0.72 + r.nextDouble() * 0.45;
    final turnover = 5 + r.nextDouble() * 18;
    final drawdown = 2 + r.nextDouble() * 8;
    final result = SimulationResult(
      formula: formula,
      sharpe: double.parse(sharpe.toStringAsFixed(2)),
      fitness: double.parse(fitness.toStringAsFixed(2)),
      turnover: double.parse(turnover.toStringAsFixed(2)),
      drawdown: double.parse(drawdown.toStringAsFixed(2)),
      timestamp: DateTime.now(),
    );
    history.insert(0, result);
    notifyListeners();
    return result;
  }

  double correlationWithVault(String formula) {
    if (vault.isEmpty) return 0;
    final a = formula.codeUnits;
    double best = 0;
    for (final alpha in vault) {
      final b = alpha.formula.codeUnits;
      final n = min(a.length, b.length);
      if (n == 0) continue;
      int same = 0;
      for (int i = 0; i < n; i++) {
        if (a[i] == b[i]) same++;
      }
      final structural = same / n;
      final fieldOverlap = fields.where((f) =>
          formula.contains(f) && alpha.formula.contains(f)).length;
      final c = min(0.99, structural * 0.65 + fieldOverlap * 0.12);
      best = max(best, c);
    }
    return double.parse(best.toStringAsFixed(2));
  }

  String reduceCorrelation(String formula) {
    final replacements = <String, String>{
      '60': '90',
      '90': '120',
      '20': '40',
      '40': '60',
      'ts_delta': 'ts_rank',
      'ts_rank': 'ts_decay_linear',
    };
    var output = formula;
    for (final e in replacements.entries) {
      if (output.contains(e.key)) {
        output = output.replaceFirst(e.key, e.value);
        break;
      }
    }
    return output;
  }
}

class Alpha {
  final String id;
  final String name;
  final String formula;
  final double sharpe;
  final double fitness;
  final double correlation;
  final String region;
  Alpha({
    required this.id,
    required this.name,
    required this.formula,
    required this.sharpe,
    required this.fitness,
    required this.correlation,
    required this.region,
  });
}

class SimulationResult {
  final String formula;
  final double sharpe;
  final double fitness;
  final double turnover;
  final double drawdown;
  final DateTime timestamp;
  SimulationResult({
    required this.formula,
    required this.sharpe,
    required this.fitness,
    required this.turnover,
    required this.drawdown,
    required this.timestamp,
  });
}

class SaintAlphaApp extends StatelessWidget {
  final SaintStore store;
  const SaintAlphaApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Saint Alpha',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorSchemeSeed: Colors.indigo,
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFF090D18),
        ),
        home: Home(store: store),
      ),
    );
  }
}

class Home extends StatefulWidget {
  final SaintStore store;
  const Home({super.key, required this.store});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(store: widget.store),
      Research(store: widget.store),
      Fields(store: widget.store),
      Vault(store: widget.store),
      Settings(store: widget.store),
    ];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'Research'),
          NavigationDestination(icon: Icon(Icons.data_object), label: 'Fields'),
          NavigationDestination(icon: Icon(Icons.verified_outlined), label: 'Vault'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Settings'),
        ],
      ),
    );
  }
}

class Shell extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  const Shell({super.key, required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(subtitle, style: TextStyle(color: Colors.grey.shade400)),
        const SizedBox(height: 20),
        child,
      ],
    ),
  );
}

class Stat extends StatelessWidget {
  final String title, value, note;
  final IconData icon;
  const Stat({super.key, required this.title, required this.value, required this.note, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        Icon(icon, size: 30),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          Text(note, style: TextStyle(color: Colors.grey.shade400)),
        ])),
      ]),
    ),
  );
}

class Dashboard extends StatelessWidget {
  final SaintStore store;
  const Dashboard({super.key, required this.store});
  @override
  Widget build(BuildContext context) => Shell(
    title: 'Saint Alpha',
    subtitle: 'Research. Simulate. Evolve.',
    child: Column(children: [
      Stat(title: 'Field Library', value: '${store.fields.length} fields', note: 'Ready for research', icon: Icons.data_object),
      Stat(title: 'Approved Alphas', value: '${store.vault.length}', note: 'Protected by correlation guard', icon: Icons.verified),
      Stat(title: 'Experiments', value: '${store.history.length}', note: 'Simulation history', icon: Icons.science),
      Stat(title: 'Active Profile', value: '${store.region} • ${store.universe}', note: 'Delay ${store.delay} • Decay ${store.decay}', icon: Icons.tune),
      const SizedBox(height: 10),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Core workflow', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('Hypothesis → Fields → Generate → Simulate → Correlation → Improve → Approve'),
          ]),
        ),
      ),
    ]),
  );
}

class Research extends StatefulWidget {
  final SaintStore store;
  const Research({super.key, required this.store});
  @override
  State<Research> createState() => _ResearchState();
}

class _ResearchState extends State<Research> {
  final hypothesis = TextEditingController();
  String formula = 'rank(ts_delta(fnd6_newa1v1300_eps,60))';
  SimulationResult? result;
  double correlation = 0;
  String message = 'Enter a hypothesis to begin.';

  void generate() {
    final h = hypothesis.text.trim().toLowerCase();
    setState(() {
      if (h.contains('news') || h.contains('sentiment')) {
        formula = 'rank(ts_decay_linear(ts_delta(equity_sentiment_score,20),10)) + rank(-ts_rank(returns,20))';
      } else if (h.contains('fundamental') || h.contains('eps')) {
        formula = 'rank(ts_delta(fnd6_newa1v1300_eps,60)) + rank(ts_delta(anl4_cfo_value,60))';
      } else if (h.contains('momentum')) {
        formula = 'rank(ts_rank(fscore_momentum,60)) - rank(ts_rank(returns,20))';
      } else {
        formula = 'rank(ts_decay_linear(ts_delta(fnd6_newa1v1300_eps,60),10)) + rank(-ts_rank(returns,20))';
      }
      correlation = widget.store.correlationWithVault(formula);
      message = 'Candidate generated. Screen it before approval.';
    });
  }

  void simulate() {
    setState(() {
      result = widget.store.simulate(formula);
      correlation = widget.store.correlationWithVault(formula);
      message = correlation > widget.store.maxCorrelation
          ? 'High correlation detected. Try Reduce Correlation.'
          : 'Simulation complete. Candidate is within correlation limit.';
    });
  }

  void reduce() {
    setState(() {
      formula = widget.store.reduceCorrelation(formula);
      correlation = widget.store.correlationWithVault(formula);
      message = 'A controlled variant was created. Re-simulate it.';
    });
  }

  void approve() {
    if (result == null) return;
    if (correlation > widget.store.maxCorrelation) {
      setState(() => message = 'Approval blocked: correlation exceeds ${widget.store.maxCorrelation}.');
      return;
    }
    widget.store.vault.add(Alpha(
      id: 'SA-${(widget.store.vault.length + 1).toString().padLeft(3, '0')}',
      name: 'Research Candidate',
      formula: formula,
      sharpe: result!.sharpe,
      fitness: result!.fitness,
      correlation: correlation,
      region: widget.store.region,
    ));
    setState(() => message = 'Approved and stored in Alpha Vault.');
  }

  @override
  Widget build(BuildContext context) => Shell(
    title: 'Research Lab',
    subtitle: 'Build diverse hypotheses and test candidates.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextField(
        controller: hypothesis,
        maxLines: 4,
        decoration: const InputDecoration(
          labelText: 'Economic hypothesis',
          hintText: 'Example: negative company-specific news may cause delayed price adjustment over 5–10 days.',
          border: OutlineInputBorder(),
        ),
      ),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: generate, icon: const Icon(Icons.auto_awesome), label: const Text('Generate Candidate')),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: SelectableText(formula))),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: simulate, icon: const Icon(Icons.play_arrow), label: const Text('Simulate'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(onPressed: reduce, icon: const Icon(Icons.build), label: const Text('Reduce Correlation'))),
      ]),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: approve, icon: const Icon(Icons.verified), label: const Text('Approve Alpha')),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(message),
        const SizedBox(height: 8),
        Text('Max correlation: ${widget.store.maxCorrelation.toStringAsFixed(2)}'),
        Text('Candidate correlation: ${correlation.toStringAsFixed(2)}'),
      ]))),
      if (result != null) ...[
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: MetricBox('Sharpe', result!.sharpe.toStringAsFixed(2))),
          Expanded(child: MetricBox('Fitness', result!.fitness.toStringAsFixed(2))),
        ]),
        Row(children: [
          Expanded(child: MetricBox('Turnover', '${result!.turnover.toStringAsFixed(2)}%')),
          Expanded(child: MetricBox('Drawdown', '${result!.drawdown.toStringAsFixed(2)}%')),
        ]),
        const SizedBox(height: 8),
        const Text('Prototype simulation only — validate final candidates in WorldQuant Brain.', style: TextStyle(fontSize: 12)),
      ],
    ]),
  );
}

class MetricBox extends StatelessWidget {
  final String label, value;
  const MetricBox(this.label, this.value, {super.key});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
    Text(label, style: TextStyle(color: Colors.grey.shade400)),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
  ])));
}

class Fields extends StatelessWidget {
  final SaintStore store;
  const Fields({super.key, required this.store});

  @override
  Widget build(BuildContext context) => Shell(
    title: 'Field Library',
    subtitle: 'Store fields and make them available to the research engine.',
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FilledButton.icon(
        onPressed: () => _add(context),
        icon: const Icon(Icons.add),
        label: const Text('Add Field'),
      ),
      const SizedBox(height: 12),
      ...store.fields.map((f) => Card(child: ListTile(
        title: Text(f),
        subtitle: Text('${store.region} • Available'),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline),
          onPressed: () => store.removeField(f),
        ),
      ))),
    ]),
  );

  void _add(BuildContext context) {
    final c = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Add Field'),
      content: TextField(controller: c, decoration: const InputDecoration(hintText: 'Field name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () { store.addField(c.text); Navigator.pop(context); }, child: const Text('Save')),
      ],
    ));
  }
}

class Vault extends StatelessWidget {
  final SaintStore store;
  const Vault({super.key, required this.store});
  @override
  Widget build(BuildContext context) => Shell(
    title: 'Alpha Vault',
    subtitle: 'Approved alphas used as references for future diversity screening.',
    child: Column(children: [
      ...store.vault.map((a) => Card(child: ExpansionTile(
        leading: const Icon(Icons.verified),
        title: Text('${a.id} • ${a.name}'),
        subtitle: Text('Sharpe ${a.sharpe.toStringAsFixed(2)} • Fitness ${a.fitness.toStringAsFixed(2)} • Corr ${a.correlation.toStringAsFixed(2)}'),
        children: [Padding(padding: const EdgeInsets.all(16), child: SelectableText(a.formula))],
      ))),
      const SizedBox(height: 12),
      const Text('New candidates are checked against this vault before approval.'),
    ]),
  );
}

class Settings extends StatelessWidget {
  final SaintStore store;
  const Settings({super.key, required this.store});

  @override
  Widget build(BuildContext context) => Shell(
    title: 'Settings',
    subtitle: 'Research configuration.',
    child: Column(children: [
      _dropdown(context, 'Region', store.region, ['USA', 'USA2', 'Europe', 'Asia Pacific', 'Japan', 'China', 'India', 'Korea']),
      _dropdown(context, 'Universe', store.universe, ['TOP3000', 'TOP1000', 'TOP500', 'TOP200']),
      _dropdown(context, 'Neutralization', store.neutralization, ['Industry', 'Subindustry', 'Sector', 'Market', 'None']),
      Card(child: ListTile(title: const Text('Delay'), trailing: Text('${store.delay}'))),
      Card(child: ListTile(title: const Text('Decay'), trailing: Text('${store.decay}'))),
      Card(child: ListTile(title: const Text('Truncation'), trailing: Text(store.truncation.toStringAsFixed(2)))),
      Card(child: ListTile(title: const Text('Maximum correlation'), trailing: Text(store.maxCorrelation.toStringAsFixed(2)))),
      const SizedBox(height: 12),
      const Text('These settings guide Saint Alpha research. Confirm available settings in your WorldQuant Brain region before final simulation.'),
    ]),
  );

  Widget _dropdown(BuildContext context, String title, String value, List<String> values) {
    return Card(child: ListTile(
      title: Text(title),
      trailing: DropdownButton<String>(
        value: values.contains(value) ? value : values.first,
        items: values.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: (v) {
          if (v == null) return;
          if (title == 'Region') store.region = v;
          if (title == 'Universe') store.universe = v;
          if (title == 'Neutralization') store.neutralization = v;
          store.save();
        },
      ),
    ));
  }
}
