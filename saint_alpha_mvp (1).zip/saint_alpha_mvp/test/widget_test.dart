import 'package:flutter_test/flutter_test.dart';
import 'package:saint_alpha/main.dart';

void main() {
  testWidgets('Saint Alpha starts', (tester) async {
    final store = await SaintStore.load();
    await tester.pumpWidget(SaintAlphaApp(store: store));
    expect(find.text('Saint Alpha'), findsOneWidget);
    expect(find.text('Research. Simulate. Evolve.'), findsOneWidget);
  });
}
